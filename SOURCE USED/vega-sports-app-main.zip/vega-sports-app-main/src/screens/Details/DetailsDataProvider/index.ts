export { useDetailsLayoutElements } from './useDetailsLayoutElements';
