import { scaleUxToDp } from '@AppUtils';

export const MENU_WIDTHS = {
  open: scaleUxToDp(300),
  closed: scaleUxToDp(100),
};
