export const serviceName = 'ApiClient';
