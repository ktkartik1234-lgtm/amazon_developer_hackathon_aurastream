// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0
export { AnimatedNavigationBarItem } from './AnimatedNavigationBarItem';
