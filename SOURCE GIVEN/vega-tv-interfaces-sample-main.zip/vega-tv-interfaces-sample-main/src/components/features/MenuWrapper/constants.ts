import { scale } from '@AppUtils/scale';

export const MENU_WIDTHS = {
  open: scale(300),
  closed: scale(100),
};
