export { FocusStyleTouchableOpacity } from './FocusStyleTouchableOpacity';
