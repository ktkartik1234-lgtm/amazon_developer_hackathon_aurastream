export const serviceName = 'NetInfo';
