export const languages = [
  { key: 'en-US', label: 'english' },
  { key: 'es', label: 'spanish' },
] as const;
