export const serviceName = 'AppConfig';
