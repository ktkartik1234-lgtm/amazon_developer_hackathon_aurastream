import React from 'react';

import { ComponentsStack } from '@AppScreens/Components/ComponentsStack';

export const ComponentsNavigator = () => {
  return <ComponentsStack />;
};
