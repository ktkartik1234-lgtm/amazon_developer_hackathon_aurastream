export enum DPADEventType {
  LEFT = 'left',
  RIGHT = 'right',
  UP = 'up',
  DOWN = 'down',
  PLAY = 'play',
  PAUSE = 'pause',
  PLAYPAUSE = 'playpause',
  SKIPBACKWARD = 'skip_backward',
  SKIPFORWARD = 'skip_forward',
  SELECT = 'select',
  MENU = 'menu',
  BACK = 'back',
  PAGE_UP = 'page_up',
  PAGE_DOWN = 'page_down',
  PAGE_LEFT = 'page_left',
  PAGE_RIGHT = 'page_right',
  INFO = 'info',
  MORE = 'more',
}

export const EVENT_KEY_DOWN = 0;
export const EVENT_KEY_UP = 1;
