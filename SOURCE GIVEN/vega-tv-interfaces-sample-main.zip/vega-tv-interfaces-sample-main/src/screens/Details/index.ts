export { Details } from './Details';
