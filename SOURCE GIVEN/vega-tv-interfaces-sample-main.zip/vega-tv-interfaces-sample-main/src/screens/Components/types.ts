export type ComponentsStackParamList = {
  ComponentsMain: undefined;
  VerticalStack: undefined;
  BrowseStack: undefined;
};
