export enum DPADEventType {
  PLAYPAUSE = 'playpause',
  FORWARD = 'forward',
  REWIND = 'rewind',
  UP = 'up',
  DOWN = 'down',
  LEFT = 'left',
  RIGHT = 'right',
  SELECT = 'select',
  BACK = 'back',
}

export const EVENT_KEY_DOWN = 0;
export const EVENT_KEY_UP = 1;

export const CAPTION_DISABLE_ID = 'DISABLED';
