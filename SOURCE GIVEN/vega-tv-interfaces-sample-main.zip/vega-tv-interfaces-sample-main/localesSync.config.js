module.exports = {
  primaryLanguage: 'en-US',
  secondaryLanguages: ['es'],
  localesFolder: './assets/text',
  spaces: 2,
};
